package com.company.employeemanagementsystem4.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum Roles implements EnumClass<Integer> {

    HR(10),
    EMPLOYEE(20);

    private final Integer id;

    Roles(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static Roles fromId(Integer id) {
        for (Roles at : Roles.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}