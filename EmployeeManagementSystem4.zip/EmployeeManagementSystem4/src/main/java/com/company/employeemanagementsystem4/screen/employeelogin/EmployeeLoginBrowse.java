package com.company.employeemanagementsystem4.screen.employeelogin;

import com.company.employeemanagementsystem4.entity.Employee;
import com.company.employeemanagementsystem4.entity.EmployeeLogin;
import com.company.employeemanagementsystem4.entity.Roles;
import io.jmix.core.DataManager;
import io.jmix.ui.Notifications;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.ComboBox;
import io.jmix.ui.component.PasswordField;
import io.jmix.ui.component.TextField;
import io.jmix.ui.model.CollectionLoader;
import io.jmix.ui.screen.*;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Arrays;

@UiController("EmployeeLogin.browse")
@UiDescriptor("employee-login-browse.xml")
@LookupComponent("employeeLoginsTable")
public class EmployeeLoginBrowse extends StandardLookup<EmployeeLogin> {


    @Autowired
    private TextField<String> emailField;
    @Autowired
    private PasswordField passwordField;
    @Autowired
    private Button loginBtn;
    @Autowired
    private Notifications notifications;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private CollectionLoader<Employee> employeesDl;
    @Autowired
    private ScreenBuilders screenBuilders;

    @Autowired
    private ComboBox<Roles> roleField;

    @Subscribe
    public void onBeforeShow(final BeforeShowEvent event) {
        roleField.setOptionsList(Arrays.asList(Roles.values()));
    }


    @Subscribe("loginBtn")
    public void onLoginBtnClick(final Button.ClickEvent event) {
        String email = emailField.getValue();
        String password = passwordField.getValue();
        Roles role = roleField.getValue();

        if (email == null || email.isEmpty() || password == null || password.isEmpty() || role == null) {
            notifications.create()
                    .withCaption("Error")
                    .withDescription("Please enter email, password, and select a role")
                    .withType(Notifications.NotificationType.ERROR)
                    .show();
            return;
        }


        if (role==Roles.HR) {

            EmployeeLogin user = dataManager.load(EmployeeLogin.class)
                    .query("select e from EmployeeLogin e where e.email = :email and e.password = :password and e.department_name = :role")
                    .parameter("email", email)
                    .parameter("password", password)
                    .parameter("role", "HR")
                    .optional()
                    .orElse(null);

            if (user == null) {
                notifications.create()
                        .withCaption("Login Failed")
                        .withDescription("Invalid email, password, or role for HR")
                        .withType(Notifications.NotificationType.ERROR)
                        .show();
            } else {
                notifications.create()
                        .withCaption("Login Successful")
                        .withDescription("Welcome HR!")
                        .withType(Notifications.NotificationType.TRAY)
                        .show();


                closeWithDefaultAction();
            }
        } else if (role == Roles.EMPLOYEE) {

            EmployeeLogin user = dataManager.load(EmployeeLogin.class)
                    .query("select e from EmployeeLogin e where e.email = :email and e.password = :password")
                    .parameter("email", email)
                    .parameter("password", password)
                    .optional()
                    .orElse(null);

            if (user == null) {
                notifications.create()
                        .withCaption("Login Failed")
                        .withDescription("Invalid email or password")
                        .withType(Notifications.NotificationType.ERROR)
                        .show();
            } else {
                notifications.create()
                        .withCaption("Login Successful")
                        .withDescription("Welcome Employee!")
                        .withType(Notifications.NotificationType.TRAY)
                        .show();


                closeWithDefaultAction();
            }
        }
    }
}