package com.company.employeemanagementsystem4.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import java.util.UUID;

@JmixEntity
@Table(name = "DEPARTMENT" ,
        uniqueConstraints = { @UniqueConstraint(name = "UNQ_DEPARTMENT_DEPARTMENT_ID", columnNames = {"DEPARTMENT_ID"})
})
@Entity
public class Department {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;
    @Column(name = "DEPARTMENT_ID",unique = true)
    private Integer department_id;
    @Column(name = "DEPARTMENT_NAME")
    private String department_name;

    public String getDepartment_name() {
        return department_name;
    }

    public void setDepartment_name(String department_name) {
        this.department_name = department_name;
    }

    public Integer getDepartment_id() {
        return department_id;
    }

    public void setDepartment_id(Integer department_id) {
        this.department_id = department_id;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Department{" +
                "id=" + id +
                ", department_id=" + department_id +
                ", department_name='" + department_name + '\'' +
                '}';
    }
}