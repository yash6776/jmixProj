package com.company.employeemanagementsystem4.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.UUID;

@JmixEntity
@Table(name = "LEAVE_REQUEST", indexes = {
        @Index(name = "IDX_LEAVE_REQUEST_EMP", columnList = "EMP_ID")
})
@Entity
public class LeaveRequest {
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;
    @InstanceName
    @NotNull
    @JoinColumn(name = "EMP_ID", referencedColumnName = "ID", nullable = false)
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    private User emp_id;

    @Temporal(TemporalType.DATE)
    @Column(name = "STARTDATE", nullable = false)
    @NotNull
    private Date startdate;
    @Temporal(TemporalType.DATE)
    @Column(name = "ENDDATE", nullable = false)
    @NotNull
    private Date enddate;

    @Column(name = "STATUS")
    private Integer status;
    @Column(name = "REASON")
    private String reason;

    public void setEmp_id(User emp_id) {
        this.emp_id = emp_id;
    }

    public User getEmp_id() {
        return emp_id;
    }

    public LeaveRequestStatus getStatus() {
        return status == null ? null : LeaveRequestStatus.fromId(status);
    }

    public void setStatus(LeaveRequestStatus status) {
        this.status = status == null ? null : status.getId();
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public Date getEnddate() {
        return enddate;
    }

    public void setEnddate(Date enddate) {
        this.enddate = enddate;
    }

    public Date getStartdate() {
        return startdate;
    }

    public void setStartdate(Date startdate) {
        this.startdate = startdate;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}