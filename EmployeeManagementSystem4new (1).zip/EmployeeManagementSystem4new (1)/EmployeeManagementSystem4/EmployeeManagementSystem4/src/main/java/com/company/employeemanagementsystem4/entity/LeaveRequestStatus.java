package com.company.employeemanagementsystem4.entity;

import io.jmix.core.metamodel.datatype.impl.EnumClass;

import javax.annotation.Nullable;


public enum LeaveRequestStatus implements EnumClass<Integer> {

    PENDING(10),
    APPROVED(20),
    REJECTED(30);

    private final Integer id;

    LeaveRequestStatus(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    @Nullable
    public static LeaveRequestStatus fromId(Integer id) {
        for (LeaveRequestStatus at : LeaveRequestStatus.values()) {
            if (at.getId().equals(id)) {
                return at;
            }
        }
        return null;
    }
}