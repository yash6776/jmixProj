package com.company.employeemanagementsystem4.entity;

import io.jmix.core.entity.annotation.JmixGeneratedValue;
import io.jmix.core.metamodel.annotation.InstanceName;
import io.jmix.core.metamodel.annotation.JmixEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.UUID;

@JmixEntity
@Table(name = "SHIFT_TIMING")
@Entity
public class ShiftTiming {
    @InstanceName
    @JmixGeneratedValue
    @Column(name = "ID", nullable = false)
    @Id
    private UUID id;
    @Column(name = "SHIFT_TIMING")
    private String shift_timings;

    public String getShift_timings() {
        return shift_timings;
    }

    public void setShift_timings(String shift_timings) {
        this.shift_timings = shift_timings;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }
}