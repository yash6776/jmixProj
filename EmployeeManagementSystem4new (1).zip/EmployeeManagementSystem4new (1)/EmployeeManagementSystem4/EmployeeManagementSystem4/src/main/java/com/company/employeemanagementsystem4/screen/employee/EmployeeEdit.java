package com.company.employeemanagementsystem4.screen.employee;

import com.company.employeemanagementsystem4.entity.Employee;
import io.jmix.ui.Notifications;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.PasswordField;
import io.jmix.ui.component.TextField;
import io.jmix.ui.model.DataContext;
import io.jmix.ui.screen.*;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("Employee.edit")
@UiDescriptor("employee-edit.xml")
@EditedEntityContainer("employeeDc")
public class EmployeeEdit extends StandardEditor<Employee> {


    @Autowired
    private PasswordField passwordField;
    @Autowired
    private PasswordField confirmPasswordField;
    @Autowired
    private Notifications notifications;
    @Autowired
    private DataContext dataContext;


    @Subscribe
    public void onBeforeCommitChanges(final BeforeCommitChangesEvent event) {
        String password = passwordField.getValue();
        String confirmPassword = confirmPasswordField.getValue();

        if (password == null || confirmPassword == null) {
            notifications.create().withCaption("Error")
                    .withDescription("Passwords Cannot be null")
                    .withType(Notifications.NotificationType.ERROR).show();
            event.preventCommit();
        } else if (!passwordField.getValue().equals(confirmPasswordField.getValue())) {
            notifications.create().withCaption("Error")
                    .withDescription("Passwords do not match!")
                    .withType(Notifications.NotificationType.ERROR).show();
            event.preventCommit();
        }
    }


    @Subscribe("commitAndCloseBtn")
    public void onCommitAndCloseBtnClick(final Button.ClickEvent event) {
Employee employee=getEditedEntity();
if(employee.getId()==null){
    notifications.create()
          .withCaption( "Employee added successfully")
          .show();
}
else {
    notifications.create()
            .withCaption( "Employee edited successfully")
            .show();
}
    }

}


//    private boolean isNewEntity;
//
//    @Subscribe
//    public void onBeforeCommitChanges1(final BeforeCommitChangesEvent event) {
//
//        Employee employee = getEditedEntity();
//        isNewEntity = employee.getId() == null;
//    }
//
//    @Subscribe
//    public void onAfterCommitChanges(final AfterCommitChangesEvent event) {
//        notifications.create()
//                .withCaption(isNewEntity ? "Employee added successfully" : "Employee edited successfully")
//                .show();
//    }
//        }


    
