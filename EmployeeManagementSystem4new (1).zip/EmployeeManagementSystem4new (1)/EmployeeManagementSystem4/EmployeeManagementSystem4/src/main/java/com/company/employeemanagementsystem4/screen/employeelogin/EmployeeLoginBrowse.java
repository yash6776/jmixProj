//package com.company.employeemanagementsystem4.screen.employeelogin;
//
//import com.company.employeemanagementsystem4.entity.*;
//import com.company.employeemanagementsystem4.screen.leaverequest.LeaveRequestEdit;
//import io.jmix.core.DataManager;
//import io.jmix.ui.Notifications;
//import io.jmix.ui.ScreenBuilders;
//import io.jmix.ui.Screens;
//import io.jmix.ui.component.Button;
//import io.jmix.ui.component.ComboBox;
//import io.jmix.ui.component.PasswordField;
//import io.jmix.ui.component.TextField;
//import io.jmix.ui.model.CollectionLoader;
//import io.jmix.ui.screen.*;
//import org.springframework.beans.factory.annotation.Autowired;
//
//import java.util.Arrays;
//
//@UiController("EmployeeLogin.browse")
//@UiDescriptor("employee-login-browse.xml")
//@LookupComponent("employeeLoginsTable")
//public class EmployeeLoginBrowse extends StandardLookup<Employee> {
//
//
//    @Autowired
//    private TextField<String> emailField;
//    @Autowired
//    private PasswordField passwordField;
//    @Autowired
//    private Button loginBtn;
//    @Autowired
//    private Notifications notifications;
//    @Autowired
//    private DataManager dataManager;
//    @Autowired
//    private CollectionLoader<Employee> employeesDl;
//    @Autowired
//    private ScreenBuilders screenBuilders;
//
//    @Autowired
//    private ComboBox<Roles> roleField;
//    @Autowired
//    private Screens screens;
//
//    @Subscribe
//    public void onBeforeShow(final BeforeShowEvent event) {
//        roleField.setOptionsList(Arrays.asList(Roles.values()));
//    }
//
//
//    @Subscribe("loginBtn")
//    public void onLoginBtnClick(final Button.ClickEvent event) {
//        String email = emailField.getValue();
//        String password = passwordField.getValue();
//        Roles role = roleField.getValue();
//
//        if (email == null || email.isEmpty() || password == null || password.isEmpty() || role == null) {
//            notifications.create()
//                    .withCaption("Error")
//                    .withDescription("Please enter email, password, and select a role")
//                    .withPosition(Notifications.Position.MIDDLE_CENTER)
//                    .withType(Notifications.NotificationType.ERROR)
//                    .show();
//            return;
//        }
//
//
//        if (role==Roles.HR) {
//
//            Employee user = dataManager.load(Employee.class)
//                    .query("select e from Employee e where e.email = :email and e.password = :password and e.department.department_name = :role")
//                    .parameter("email", email)
//                    .parameter("password", password)
//                    .parameter("role", "HR")
//                    .optional()
//                    .orElse(null);
//
//            if (user == null) {
//                notifications.create()
//                        .withCaption("Login Failed")
//                        .withDescription("Invalid email, password, or role for HR")
//                        .withPosition(Notifications.Position.MIDDLE_CENTER)
//                        .withType(Notifications.NotificationType.ERROR)
//                        .show();
//            } else {
//                notifications.create()
//                        .withCaption("Login Successful")
//                        .withDescription("Welcome HR!")
//                        .withPosition(Notifications.Position.MIDDLE_CENTER)
//                        .withType(Notifications.NotificationType.TRAY)
//                        .show();
//
//                screenBuilders.screen(this).
//                        withScreenId("HrDashboard.browse").
//                        withOpenMode(OpenMode.NEW_TAB).build().
//                        show();
//
//                closeWithDefaultAction();
//            }
//        }
//
//        else if (role == Roles.EMPLOYEE) {
//
//            Employee user = dataManager.load(Employee.class)
//                    .query("select e from Employee e where e.email = :email and e.password = :password")
//                    .parameter("email", email)
//                    .parameter("password", password)
//                    .optional()
//                    .orElse(null);
//
//            if (user == null) {
//                notifications.create()
//                        .withCaption("Login Failed")
//                        .withDescription("Invalid email or password")
//                        .withPosition(Notifications.Position.MIDDLE_CENTER)
//                        .withType(Notifications.NotificationType.ERROR)
//                        .show();
//            } else {
//                notifications.create()
//                        .withCaption("Login Successful")
//                        .withDescription("Welcome Employee!")
//                        .withPosition(Notifications.Position.MIDDLE_CENTER)
//                        .withType(Notifications.NotificationType.TRAY)
//                        .show();
//
//
//
//                LeaveRequestEdit leaveRequestScreen=  screenBuilders.editor(LeaveRequest.class,this)
//                        .withScreenClass(LeaveRequestEdit.class)  // Correct class name
//                        .withOpenMode(OpenMode.NEW_TAB)
//
//                        .build();
//                leaveRequestScreen.setEmployee(user); // Set the employee
//
//                leaveRequestScreen.show();
//
//
//            }
//            closeWithDefaultAction();
//        }
//
//    }
//}