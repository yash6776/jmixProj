package com.company.employeemanagementsystem4.screen.hrdashboard;

import com.company.employeemanagementsystem4.entity.Employee;
import com.company.employeemanagementsystem4.entity.HrDashboard;
import com.company.employeemanagementsystem4.entity.User;
import io.jmix.core.DataManager;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.GroupTable;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.screen.*;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("HrDashboard.browse")
@UiDescriptor("hr-dashboard-browse.xml")
@LookupComponent("usersTable")
public class HrDashboardBrowse extends StandardLookup<User> {


}




