package com.company.employeemanagementsystem4.screen.hrdashboard;

import com.company.employeemanagementsystem4.entity.Employee;
import com.company.employeemanagementsystem4.entity.HrDashboard;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.action.Action;
import io.jmix.ui.component.Button;
import io.jmix.ui.screen.*;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("HrDashboard.edit")
@UiDescriptor("hr-dashboard-edit.xml")
@EditedEntityContainer("hrDashboardDc")
public class HrDashboardEdit extends StandardEditor<Employee> {
    @Autowired
    private ScreenBuilders screenBuilders;

    @Subscribe("okBtn")
    public void onOkBtnClick(final Button.ClickEvent event) {
        closeWithCommit();
    }


//    @Subscribe("windowCommitAndClose")
//    public void onWindowCommitAndClose(final Action.ActionPerformedEvent event) {
//      commitChanges();
//
//        /*screenBuilders.screen(this).
//                withScreenId("HrDashboard.browse").
//                withOpenMode(OpenMode.NEW_TAB).build().
//                show();*/
//    }


}


