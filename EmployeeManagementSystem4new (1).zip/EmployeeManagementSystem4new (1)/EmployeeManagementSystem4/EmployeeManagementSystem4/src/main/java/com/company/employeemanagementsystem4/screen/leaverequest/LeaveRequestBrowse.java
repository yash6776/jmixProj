package com.company.employeemanagementsystem4.screen.leaverequest;

import com.company.employeemanagementsystem4.entity.LeaveRequest;
import io.jmix.ui.screen.LookupComponent;
import io.jmix.ui.screen.StandardLookup;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;

@UiController("LeaveRequest.browse")
@UiDescriptor("leave-request-browse.xml")
@LookupComponent("leaveRequestsTable")
public class LeaveRequestBrowse extends StandardLookup<LeaveRequest> {



}