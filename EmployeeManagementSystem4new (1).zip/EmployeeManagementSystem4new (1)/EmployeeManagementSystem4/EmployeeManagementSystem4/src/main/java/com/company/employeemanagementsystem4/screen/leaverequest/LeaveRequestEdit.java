package com.company.employeemanagementsystem4.screen.leaverequest;

import com.company.employeemanagementsystem4.entity.Employee;
import com.company.employeemanagementsystem4.entity.LeaveRequest;
import com.company.employeemanagementsystem4.entity.LeaveRequestStatus;
import com.company.employeemanagementsystem4.entity.User;
import io.jmix.core.DataManager;
import io.jmix.core.security.CurrentAuthentication;
import io.jmix.ui.Notifications;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.ComboBox;
import io.jmix.ui.component.DateField;
import io.jmix.ui.component.TextField;
import io.jmix.ui.screen.*;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Arrays;
import java.util.Date;

@UiController("LeaveRequest.edit")
@UiDescriptor("leave-request-edit.xml")
@EditedEntityContainer("leaveRequestDc")
public class LeaveRequestEdit extends StandardEditor<LeaveRequest> {

    private User user;

    @Autowired
    private CurrentAuthentication currentAuthentication;
    @Autowired

    private TextField<String> statusField;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private Notifications notifications;
    @Autowired
    private DateField<Date> startdateField;
    @Autowired
    private DateField<Date> enddateField;

    public void setEmployee(User user) {
        this.user = user;
        getEditedEntity().setEmp_id(user);
    }

    @Subscribe
    public void onInit(final InitEvent event) {


    }

    
    @Subscribe("submitBtn")
    public void onSubmitBtnClick(final Button.ClickEvent event) {


        Date startDate= getEditedEntity().getStartdate();
        Date endDate=getEditedEntity().getEnddate();

        if (startDate == null || endDate == null) {
            notifications.create(Notifications.NotificationType.WARNING)
                    .withCaption("Missing dates")
                    .withDescription("Both start and end dates are required")
                    .show();
            return;
        }

        if (endDate.before(startDate)) {
            notifications.create(Notifications.NotificationType.WARNING)
                    .withCaption("Invalid dates")
                    .withDescription("End date cannot be earlier than start date")
                    .show();
            return;
        }

        User currentUser = (User) currentAuthentication.getUser();

        long leaveRequestCount = dataManager.loadValue("select count(e) from LeaveRequest e where e.emp_id = :user",Long.class)

                .parameter("user", currentUser)
                .one();

        if (leaveRequestCount >= 3) {
            notifications.create(Notifications.NotificationType.WARNING)
                    .withCaption("Leave Request Limit Exceeded")
                    .withDescription("You cannot apply for more than 3 leave requests.")
                    .show();
            return;
        }

        LeaveRequest leaveRequest = getEditedEntity();

        leaveRequest.setEmp_id(currentUser); // Set the User entity
        leaveRequest.setStatus(LeaveRequestStatus.PENDING); // Use the enum

        commitChanges();
            closeWithCommit();


    }

}