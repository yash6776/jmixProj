package com.company.employeemanagementsystem4.screen.leaverequest;
import io.jmix.ui.Notifications;
import io.jmix.ui.UiComponents;
import io.jmix.ui.component.*;
import io.jmix.ui.component.data.TableItems;
import io.jmix.ui.model.CollectionContainer;
import io.jmix.ui.model.CollectionLoader;
import io.jmix.ui.screen.LookupComponent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.company.employeemanagementsystem4.entity.LeaveRequest;
import com.company.employeemanagementsystem4.entity.LeaveRequestStatus;
import io.jmix.core.DataManager;
import io.jmix.ui.action.Action;
import io.jmix.ui.model.DataContext;
import io.jmix.ui.screen.*;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@UiController("LeaveRequesthr")
@UiDescriptor("leave-request-hr.xml")
@LookupComponent("leaveRequestsTable")


public class LeaveRequestHr extends StandardLookup<LeaveRequest> {
    @Autowired
    private DataContext dataContext;
    @Autowired
    private GroupTable<LeaveRequest> leaveRequestsTable;
    @Autowired
    private CollectionContainer<LeaveRequest> leaveRequestsDc;
    @Autowired
    private DataManager dataManager;
    @Autowired
    private CollectionLoader<LeaveRequest> leaveRequestsDl;
    @Autowired
    private UiComponents uiComponents;
    @Autowired
    private Notifications notifications;

    @Subscribe
    public void onInit(InitEvent event) {
        leaveRequestsDl.load();
        leaveRequestsTable.addGeneratedColumn("actionsColumn", this::generateActionsColumn);
    }

    private Component generateActionsColumn(LeaveRequest leaveRequest){


        HBoxLayout HBox= uiComponents.create(HBoxLayout.class);
        HBox.setSpacing(true);

        Button approveBtn = uiComponents.create(Button.class);

        approveBtn.setCaption("Approve");
        approveBtn.addClickListener(clickEvent -> {

            leaveRequest.setStatus(LeaveRequestStatus.APPROVED);
            notifications.create().withCaption("Leave Request Approved").show();
                dataManager.save(leaveRequest);
                leaveRequestsDl.load(); // Refresh table

            }
        );

        Button rejectBtn = uiComponents.create(Button.class);
        rejectBtn.setCaption("Reject");
        rejectBtn.addClickListener(clickEvent -> {

            leaveRequest.setStatus(LeaveRequestStatus.REJECTED);
            notifications.create().withCaption("Leave Request Rejected").show();
            dataManager.save(leaveRequest);
            leaveRequestsDl.load(); // Refresh table
        });

HBox.add(approveBtn);
HBox.add(rejectBtn);
return HBox;



}






    //    @Install(to = "leaveRequestsTable.approveBtn", subject = "columnGenerator")
//    private Component leaveRequestsTableApproveBtnColumnGenerator(final LeaveRequest leaveRequest) {
//        return null;
//    }





//        @Subscribe("leaveRequestsTable.approve")
//    public void onLeaveRequestsTableApprove(final Action.ActionPerformedEvent event) {
//        LeaveRequest selectedLeaveRequest = leaveRequestsTable.getSingleSelected();
//        if (selectedLeaveRequest != null) {
//            selectedLeaveRequest.setStatus(LeaveRequestStatus.APPROVED);
//            dataManager.save(selectedLeaveRequest);
//            leaveRequestsDl.load();
//        }
//    }
//
//    @Subscribe("leaveRequestsTable.reject")
//    public void onLeaveRequestsTableReject(final Action.ActionPerformedEvent event) {
//        LeaveRequest selectedLeaveRequest = leaveRequestsTable.getSingleSelected();
//        if (selectedLeaveRequest != null) {
//            selectedLeaveRequest.setStatus(LeaveRequestStatus.REJECTED);
//            dataManager.save(selectedLeaveRequest);
//            leaveRequestsDl.load();
//        }
//    }
    
    
    
}







    
