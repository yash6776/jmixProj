package com.company.employeemanagementsystem4.screen.shifttiming;

import com.company.employeemanagementsystem4.entity.ShiftTiming;
import com.company.employeemanagementsystem4.entity.User;
import io.jmix.core.DataManager;
import io.jmix.ui.ScreenBuilders;
import io.jmix.ui.component.Button;
import io.jmix.ui.screen.*;
import liquibase.pro.packaged.U;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("EmployeeShiftTiming.browse")
@UiDescriptor("Employee-shift-timing-browse.xml")
@LookupComponent("shiftTimingsTable")
public class EmployeeShiftTimingBrowse extends StandardLookup<ShiftTiming> {
    @Autowired
    private ScreenBuilders screenBuilders;
    @Autowired
    private DataManager dataManager;


    @Subscribe("shiftTimingBtn")
    public void onShiftTimingBtnClick(final Button.ClickEvent event) {

        screenBuilders.editor(ShiftTiming.class, this)
                .withScreenClass(EmployeeShiftTimingEdit.class)  // Correct class name
                .withOpenMode(OpenMode.DIALOG)
                .build().show();


//                ShiftTiming selectedShiftTiming = editor.getSelectedShiftTiming();
//                if (selectedShiftTiming != null) {
//                    User user = dataManager.load(User.class)
//                    if (user != null) {
//                        user.setShift_timing(selectedShiftTiming);
//                        userDc.setItem(user);
//                    }
//                }
//            }


    }
}