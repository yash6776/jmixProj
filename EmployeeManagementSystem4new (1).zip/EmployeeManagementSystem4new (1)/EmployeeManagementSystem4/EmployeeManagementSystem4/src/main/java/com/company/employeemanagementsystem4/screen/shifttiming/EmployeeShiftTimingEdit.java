package com.company.employeemanagementsystem4.screen.shifttiming;

import com.company.employeemanagementsystem4.entity.ShiftTiming;
import com.company.employeemanagementsystem4.entity.User;
import io.jmix.core.DataManager;
import io.jmix.core.security.CurrentAuthentication;
import io.jmix.ui.Notifications;
import io.jmix.ui.component.Button;
import io.jmix.ui.component.EntityComboBox;
import io.jmix.ui.model.InstanceContainer;
import io.jmix.ui.screen.*;
import org.springframework.beans.factory.annotation.Autowired;

@UiController("EmployeeShiftTiming.edit")
@UiDescriptor("employee-shift-timing-edit.xml")
@EditedEntityContainer("shiftTimingDc")



public class EmployeeShiftTimingEdit extends StandardEditor<ShiftTiming> {
    @Autowired
    private DataManager dataManager;
    @Autowired
    private InstanceContainer<ShiftTiming> shiftTimingDc;
    @Autowired
    private EntityComboBox<ShiftTiming> shiftTimingCombo;

    private User user;
    @Autowired
    private Notifications notifications;
    @Autowired
    private CurrentAuthentication currentAuthentication;

//    public void setUser(User user) {  // Method to set the User entity
//        this.user = user;
//    }

    @Subscribe
    public void onInit(final InitEvent event) {
        user=(User) currentAuthentication.getUser();
    }


    
    @Subscribe("submitBtn")
    public void onSubmitBtnClick(final Button.ClickEvent event) {
        ShiftTiming selectedShiftTiming = shiftTimingCombo.getValue();

        if (selectedShiftTiming != null && user != null) {
            user.setShift_timing(selectedShiftTiming); // Assign shift to user
            dataManager.save(user); // Save user entity

            notifications.create().
                    withCaption("Shift timing updated successfully!")
                    .withType(Notifications.NotificationType.HUMANIZED).show();
            close(StandardOutcome.COMMIT);
        } else {
            notifications.create().
                    withCaption("Please select a shift timing!")
                    .withType(Notifications.NotificationType.HUMANIZED).show();
        }
    }
    }








