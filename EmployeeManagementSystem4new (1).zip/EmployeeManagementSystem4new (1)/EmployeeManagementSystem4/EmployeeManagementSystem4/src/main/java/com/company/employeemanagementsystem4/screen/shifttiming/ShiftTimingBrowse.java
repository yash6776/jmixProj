package com.company.employeemanagementsystem4.screen.shifttiming;

import com.company.employeemanagementsystem4.entity.ShiftTiming;
import io.jmix.ui.screen.LookupComponent;
import io.jmix.ui.screen.StandardLookup;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;

@UiController("ShiftTiming.browse")
@UiDescriptor("shift-timing-browse.xml")
@LookupComponent("shiftTimingsTable")
public class ShiftTimingBrowse extends StandardLookup<ShiftTiming> {
    
    
    
}