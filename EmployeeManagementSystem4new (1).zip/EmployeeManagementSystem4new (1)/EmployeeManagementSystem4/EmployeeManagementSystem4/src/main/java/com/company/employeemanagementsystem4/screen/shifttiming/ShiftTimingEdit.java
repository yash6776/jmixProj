package com.company.employeemanagementsystem4.screen.shifttiming;

import com.company.employeemanagementsystem4.entity.ShiftTiming;
import io.jmix.ui.screen.EditedEntityContainer;
import io.jmix.ui.screen.StandardEditor;
import io.jmix.ui.screen.UiController;
import io.jmix.ui.screen.UiDescriptor;

@UiController("ShiftTiming.edit")
@UiDescriptor("shift-timing-edit.xml")
@EditedEntityContainer("shiftTimingDc")
public class ShiftTimingEdit extends StandardEditor<ShiftTiming> {
}