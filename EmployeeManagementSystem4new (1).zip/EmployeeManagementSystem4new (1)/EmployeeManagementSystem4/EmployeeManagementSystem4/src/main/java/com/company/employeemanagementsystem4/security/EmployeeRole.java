package com.company.employeemanagementsystem4.security;

import com.company.employeemanagementsystem4.entity.LeaveRequest;
import com.company.employeemanagementsystem4.entity.ShiftTiming;
import com.company.employeemanagementsystem4.entity.User;
import io.jmix.security.model.EntityAttributePolicyAction;
import io.jmix.security.model.EntityPolicyAction;
import io.jmix.security.role.annotation.EntityAttributePolicy;
import io.jmix.security.role.annotation.EntityPolicy;
import io.jmix.security.role.annotation.ResourceRole;
import io.jmix.securityui.role.annotation.MenuPolicy;
import io.jmix.securityui.role.annotation.ScreenPolicy;

@ResourceRole(name = "Employee", code = EmployeeRole.CODE, scope = "UI")
public interface EmployeeRole {
    String CODE = "employee";

    @MenuPolicy(menuIds = {"LeaveRequest.browse", "EmployeeShiftTiming.browse"})
    @ScreenPolicy(screenIds = {"LeaveRequest.edit", "LeaveRequest.browse", "EmployeeShiftTiming.edit", "EmployeeShiftTiming.browse"})
    void screens();

    @EntityAttributePolicy(entityClass = LeaveRequest.class, attributes = "noOfLeaveRequest", action = EntityAttributePolicyAction.VIEW)
    @EntityAttributePolicy(entityClass = LeaveRequest.class, attributes = {"id", "emp_id", "startdate", "enddate", "status", "reason"}, action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = LeaveRequest.class, actions = EntityPolicyAction.ALL)
    void leaveRequest();

    @EntityPolicy(entityClass = User.class, actions = {EntityPolicyAction.UPDATE, EntityPolicyAction.READ})
    @EntityAttributePolicy(entityClass = User.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    void user();

    @EntityAttributePolicy(entityClass = ShiftTiming.class, attributes = "shift_timings", action = EntityAttributePolicyAction.MODIFY)
    @EntityAttributePolicy(entityClass = ShiftTiming.class, attributes = "id", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = ShiftTiming.class, actions = {EntityPolicyAction.READ, EntityPolicyAction.UPDATE})
    void shiftTiming();
}