package com.company.employeemanagementsystem4.security;

import com.company.employeemanagementsystem4.entity.*;
import io.jmix.security.model.EntityAttributePolicyAction;
import io.jmix.security.model.EntityPolicyAction;
import io.jmix.security.role.annotation.EntityAttributePolicy;
import io.jmix.security.role.annotation.EntityPolicy;
import io.jmix.security.role.annotation.ResourceRole;
import io.jmix.securityui.role.annotation.MenuPolicy;
import io.jmix.securityui.role.annotation.ScreenPolicy;

@ResourceRole(name = "HR Manager", code = HRManagerRole.CODE, scope = "UI")
public interface HRManagerRole {
    String CODE = "hr-manager";

    @EntityAttributePolicy(entityClass = Employee.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    void employee();

    @EntityAttributePolicy(entityClass = Department.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = Department.class, actions = EntityPolicyAction.READ)
    void department();

    @MenuPolicy(menuIds = {"HrDashboard.browse", "Department.browse", "LeaveRequesthr"})
    @ScreenPolicy(screenIds = {"HrDashboard.browse", "HrDashboard.edit", "Department.browse", "User.edit", "LeaveRequesthr"})
    void screens();

    @EntityAttributePolicy(entityClass = HrDashboard.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = HrDashboard.class, actions = {EntityPolicyAction.READ, EntityPolicyAction.UPDATE})
    void hrDashboard();

    @EntityAttributePolicy(entityClass = User.class, attributes = {"firstName", "lastName", "emp_id", "dateofjoining", "noOfLeaveRequest"}, action = EntityAttributePolicyAction.MODIFY)
    @EntityPolicy(entityClass = User.class, actions = {EntityPolicyAction.READ, EntityPolicyAction.UPDATE, EntityPolicyAction.DELETE})
    void user();

    @EntityAttributePolicy(entityClass = LeaveRequest.class, attributes = "*", action = EntityAttributePolicyAction.VIEW)
    @EntityPolicy(entityClass = LeaveRequest.class, actions = {EntityPolicyAction.READ, EntityPolicyAction.UPDATE, EntityPolicyAction.DELETE})
    void leaveRequest();
}