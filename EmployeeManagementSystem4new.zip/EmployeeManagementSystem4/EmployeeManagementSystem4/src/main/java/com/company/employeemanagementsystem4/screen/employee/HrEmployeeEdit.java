package com.company.employeemanagementsystem4.screen.employee;

import com.company.employeemanagementsystem4.entity.Employee;
import io.jmix.ui.component.Form;
import io.jmix.ui.screen.*;

import javax.inject.Inject;

@UiController("HrEmployee.edit")
@UiDescriptor("hrEmployee-edit.xml")
@EditedEntityContainer("employeeDc")
public class HrEmployeeEdit extends StandardEditor<Employee> {




}